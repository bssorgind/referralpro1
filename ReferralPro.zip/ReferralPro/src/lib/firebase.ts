
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, signInWithCustomToken } from "firebase/auth";
import { getFirestore, doc, getDoc } from "firebase/firestore";
import type { User } from "./types";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);

/**
 * Checks if a user exists in Firestore based on their phone number, which is used as the document ID.
 * @param phoneNumber The full phone number including country code (e.g., +919999999999).
 * @returns The user data if found, otherwise null.
 */
export const checkUserExistsByPhone = async (phoneNumber: string): Promise<User | null> => {
  // Since the document ID is the phone number, we can fetch it directly.
  const userDocRef = doc(db, "users", phoneNumber);
  const userDoc = await getDoc(userDocRef);
  
  if (userDoc.exists()) {
    // The user's data is the content of the document.
    return userDoc.data() as User;
  }
  
  return null;
};


export { app, auth, db, signInWithCustomToken };
