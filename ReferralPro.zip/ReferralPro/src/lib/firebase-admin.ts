
'use server';

import * as admin from 'firebase-admin';
import type { App } from 'firebase-admin/app';
import { serviceAccount } from './firebase-admin-credentials';

// This function initializes the Firebase Admin SDK.
// It is designed to be idempotent, meaning it can be called multiple times without re-initializing.
function initializeAdminApp(): App {
  // If the app is already initialized, return the existing instance.
  if (admin.apps.length > 0) {
    return admin.app();
  }

  // Initialize with the imported service account object.
  try {
    return admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
    });
  } catch (error: any) {
    console.error('Firebase Admin SDK initialization error:', error.stack);
    throw new Error(
      'Firebase Admin SDK failed to initialize. The service account credentials in src/lib/firebase-admin-credentials.ts might be malformed. Check server logs for details.'
    );
  }
}

export { initializeAdminApp };
