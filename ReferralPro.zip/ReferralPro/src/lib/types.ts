import type { LucideIcon } from "lucide-react";
import type { Timestamp } from "firebase/firestore";

export type Role = {
  level: number;
  name: string;
  icon: LucideIcon;
  directReferralsNeeded: number;
  teamReferralsNeeded: number;
};

export type User = {
  uid: string;
  fullName: string;
  memberId: string;
  referralCode: string;
  referralLink: string;
  referredBy: string | null;
  dob: string | null;
  email: string | null;
  phone: string;
  pin: string;
  address: {
    houseNo: string | null;
    street: string | null;
    villageCity: string;
    mandal: string;
    district: string;
    state: string;
    pincode: string | null;
  };
  role: string;
  currentRoleLevel: number;
  directReferrals: number;
  teamReferrals: number;
  createdAt: Timestamp;
};
