import { Award, BadgeIndianRupee, Building, Gem, Shield, Star, User as UserIcon, Users, Crown } from "lucide-react";
import type { Role } from "./types";

export const ROLES: Role[] = [
  { level: 0, name: "Root Administrator", icon: Crown, directReferralsNeeded: Infinity, teamReferralsNeeded: Infinity },
  { level: 1, name: "Member", icon: UserIcon, directReferralsNeeded: 0, teamReferralsNeeded: 0 },
  { level: 2, name: "Volunteer", icon: Star, directReferralsNeeded: 10, teamReferralsNeeded: 0 },
  { level: 3, name: "Team Leader", icon: Users, directReferralsNeeded: 0, teamReferralsNeeded: 100 },
  { level: 4, name: "Area Coordinator", icon: Building, directReferralsNeeded: 0, teamReferralsNeeded: 1000 },
  { level: 5, name: "Mandal Coordinator", icon: Shield, directReferralsNeeded: 0, teamReferralsNeeded: 10000 },
  { level: 6, name: "Constituency Coordinator", icon: Award, directReferralsNeeded: 0, teamReferralsNeeded: 100000 },
  { level: 7, name: "District Coordinator", icon: Gem, directReferralsNeeded: 0, teamReferralsNeeded: 1000000 },
  { level: 8, name: "State Coordinator", icon: BadgeIndianRupee, directReferralsNeeded: 0, teamReferralsNeeded: 10000000 },
];
