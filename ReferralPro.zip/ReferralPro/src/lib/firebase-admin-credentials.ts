
// This file contains the service account credentials for the Firebase Admin SDK.
// By storing it in a .ts file, we ensure it's bundled with the application source
// and avoid file path or environment variable issues.

import type { ServiceAccount } from 'firebase-admin';

export const serviceAccount: ServiceAccount = {
  "projectId": "bsss-105fc",
  "privateKey": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCXcP8JX6vLpf23\n1CX3JLLAzGrTgZODVcKy0gYjWC9+PP3iDPsmxJ0LlWUlwEPsy5wd+MyMz3ZDDb7/\nKFRqAqdRhJqHheP0MyTUx7Ea1E55bCFEIj0oENoo4PR3PfTINMce0YcpW6i+wCEz\nDfCu96KCocXPErhilo/nqtpdBWHWo3AaiFfg1kXpRcl0JsIbNmtDo8m9po9rBLLU\nqb6H/VhRTT0Jy7sX1sVk6Ras3ESj9ikiuxRNzAZhrnSka1UArFV0NtvlU7PXPC7m\nx6Nd7xdYgt1NiN66L/fMf1JlitARdILAVvqJ5FaA6Owa/a0im1MoY00s7PVoAjX9\nZadtqgZ/AgMBAAECggEAPZbR0eEbwBXAyqs3yXweSnSYGW6ALJCLPyhVILizj/aE\nFhPLbGfXqqdWXHUF6t6fnjzaC4YwBXMosyKWugpcO7XfFrCoFV9bYkHYUB350D3e\nhZQbJRk9cBSUt4316Bo2xNzXyEUjqnf+yIGp2a6SY+ggx2dIn6e13LTKW7xdnul2\n+TekHi7Mfw6i0zhAHbefjsM0lyFrL2D0hw6XDUWPBJGejPafRoyZ1ODbsmXt8b4W\nwJcbp2nNcN0vmn6ouH40+t3UktSLsknm6eEul0SdQg8MaC4WTNe+W6t4jhCZDZJF\n+yirYu28GxtBtZcJ89fV3GXzMSvLKnJWjdJRaXyBmQKBgQDHxjv3rp7rxKPdcoDl\nApw/vysQPMczwSyjVOBdpQGZE1GF1bL6g8NSZmv1/IQFelYYloIADk6hDFcNQ1Hx\nYrBjqPyn5fjwNWeQpkAUSedzlk5xXSF4hqxDa2lXl60q4njag44NyTrx2QuS907x\nTfmbDWgdh69VVRB9yHAvGsG/WwKBgQDCEF3OM/mHP8tAxXGK2+u7e2DEPQ1S/f3K\nId5axQeFF7r3u77POWqSYN2JUBQCk/EbMW3RP6iIbtYi48CeTT7xo7R1vxY81CKn\n/lnG/mg9rj4oE/64XMbcPFbNGUqyysWRCZMkQPGhqHnS4hy254bRkNhS/YxrvAZB\nP5VIuUcCrQKBgDsOoT+xQY3VTdPzO6N3yBUYQHTGYuUr4DRQrRtB4l0MVvdHm2dv\neFhtqtDHW4f7CGSwabH2iMwXR8zF7/15/UcY98fytkrcnscmPp9A0clbz8i3jWOB\n/H7ZzAR29FxPIwcGCQKOUHyae09xCMdRE88AgZzpNa32Pa/Rh0iFkm0tAoGARK46\nJLIsS3t+WYwHJRe0FAQUOR9KSebuHM1jvkgg4y+E0gw1+WzelLOHdANNMaReHjue\nHAIliTOAwZRNJTk9X5OKWGmqWxjQsxfHei+rgLjb8p8w9NqQ3nzUU33x+9jblvsG\ngjwhyA6yHro7Y1gJVL2ocaaePbqrlAgGs1gvE3kCgYBjf27tCuUE/Al7e9I1Xcwq\n8CTaAM6N58Zv23dW0C8mGpuYsac5cunhSXCjmmF2L/8NgrhWDZnyTLE+n1oLDo/k\nk1qZ04WHCLfadSZxj/bFXoNcuHCVkhuOFZOnC90DafUHJ4T8nGL+r1xf+s2fiXlh\nRe0yd9iWfRtxcANMDW49oQ==\n-----END PRIVATE KEY-----\n".replace(/\\n/g, '\n'),
  "clientEmail": "firebase-adminsdk-fbsvc@bsss-105fc.iam.gserviceaccount.com"
};
