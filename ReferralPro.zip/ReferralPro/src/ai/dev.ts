import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-referral-data.ts';
import '@/ai/flows/suggest-referral-strategies.ts';