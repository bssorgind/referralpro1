// src/ai/flows/summarize-referral-data.ts
'use server';

/**
 * @fileOverview Summarizes referral data for a user, providing key metrics and insights.
 *
 * - summarizeReferralData - A function that handles the summarization of referral data.
 * - SummarizeReferralDataInput - The input type for the summarizeReferralData function.
 * - SummarizeReferralDataOutput - The return type for the summarizeReferralData function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeReferralDataInputSchema = z.object({
  directReferrals: z.number().describe('The number of direct referrals.'),
  teamReferrals: z.number().describe('The number of team referrals.'),
  currentRole: z.string().describe('The current role of the user.'),
  nextRoleThreshold: z.number().describe('The number of referrals needed to reach the next role.'),
  userName: z.string().describe('The name of the user.'),
});
export type SummarizeReferralDataInput = z.infer<typeof SummarizeReferralDataInputSchema>;

const SummarizeReferralDataOutputSchema = z.object({
  summary: z.string().describe('A summary of the user referral data.'),
});
export type SummarizeReferralDataOutput = z.infer<typeof SummarizeReferralDataOutputSchema>;

export async function summarizeReferralData(input: SummarizeReferralDataInput): Promise<SummarizeReferralDataOutput> {
  return summarizeReferralDataFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeReferralDataPrompt',
  input: {schema: SummarizeReferralDataInputSchema},
  output: {schema: SummarizeReferralDataOutputSchema},
  prompt: `You are an expert in summarizing referral data for users in a multi-level marketing program.

  Given the following information about the user, provide a concise and encouraging summary of their referral performance. The summary should be no more than 2 sentences long and should highlight key achievements and areas for improvement.

  User Name: {{{userName}}}
  Current Role: {{{currentRole}}}
  Direct Referrals: {{{directReferrals}}}
  Team Referrals: {{{teamReferrals}}}
  Next Role Threshold: {{{nextRoleThreshold}}}
  `,
});

const summarizeReferralDataFlow = ai.defineFlow(
  {
    name: 'summarizeReferralDataFlow',
    inputSchema: SummarizeReferralDataInputSchema,
    outputSchema: SummarizeReferralDataOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
