// src/ai/flows/suggest-referral-strategies.ts
'use server';

/**
 * @fileOverview This file defines a Genkit flow for suggesting personalized referral strategies.
 *
 * The flow analyzes a user's current referral performance and network to provide tailored
 * strategies for improving their referral rate and achieving higher roles.
 *
 * @function suggestReferralStrategies - The main function to trigger the referral strategy suggestion flow.
 * @typedef {SuggestReferralStrategiesInput} SuggestReferralStrategiesInput - The input type for the suggestReferralStrategies function.
 * @typedef {SuggestReferralStrategiesOutput} SuggestReferralStrategiesOutput - The output type for the suggestReferralStrategies function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestReferralStrategiesInputSchema = z.object({
  userRole: z.string().describe('The current role of the user in the referral program.'),
  directReferrals: z.number().describe('The number of direct referrals made by the user.'),
  teamReferrals: z.number().describe('The total number of referrals made by the user\u2019s team.'),
  networkSize: z.number().describe('The estimated size of the user\u2019s network (e.g., social media followers, contacts).'),
  pastStrategies: z.string().optional().describe('A description of referral strategies tried in the past.'),
});

export type SuggestReferralStrategiesInput = z.infer<typeof SuggestReferralStrategiesInputSchema>;

const SuggestReferralStrategiesOutputSchema = z.object({
  strategies: z.array(
    z.string().describe('A personalized referral strategy suggestion.')
  ).describe('A list of personalized referral strategies for the user.'),
});

export type SuggestReferralStrategiesOutput = z.infer<typeof SuggestReferralStrategiesOutputSchema>;

export async function suggestReferralStrategies(input: SuggestReferralStrategiesInput): Promise<SuggestReferralStrategiesOutput> {
  return suggestReferralStrategiesFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestReferralStrategiesPrompt',
  input: {schema: SuggestReferralStrategiesInputSchema},
  output: {schema: SuggestReferralStrategiesOutputSchema},
  prompt: `You are an expert referral strategy consultant. Analyze the user's current situation and suggest personalized referral strategies.

User Role: {{{userRole}}}
Direct Referrals: {{{directReferrals}}}
Team Referrals: {{{teamReferrals}}}
Network Size: {{{networkSize}}}
Past Strategies: {{{pastStrategies}}}

Suggest 3 specific and actionable referral strategies the user can implement to improve their referral rate and achieve a higher role. Make the advice specific to the user's role and network size.

Output the strategies as a numbered list.
`,
});

const suggestReferralStrategiesFlow = ai.defineFlow(
  {
    name: 'suggestReferralStrategiesFlow',
    inputSchema: SuggestReferralStrategiesInputSchema,
    outputSchema: SuggestReferralStrategiesOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
