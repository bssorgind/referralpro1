
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { auth, checkUserExistsByPhone } from "@/lib/firebase"; 
import { RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from "firebase/auth";
import { useToast } from "@/hooks/use-toast";

declare global {
  interface Window {
    recaptchaVerifier: RecaptchaVerifier;
    confirmationResult: ConfirmationResult;
  }
}

export function LoginForm() {
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const setupRecaptcha = () => {
    if (document.getElementById('recaptcha-container') && !window.recaptchaVerifier) {
      try {
        window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
          'size': 'invisible',
          'callback': (response: any) => {
            console.log("reCAPTCHA solved:", response);
          },
          'expired-callback': () => {
            console.log("reCAPTCHA expired");
            window.recaptchaVerifier?.clear();
            window.recaptchaVerifier = undefined as any;
            setupRecaptcha();
          }
        });
        console.log("reCAPTCHA verifier initialized");
      } catch (e) {
        console.error("Recaptcha verifier error", e);
        toast({ variant: "destructive", title: "Error", description: "reCAPTCHA failed to load. Please refresh the page."});
      }
    }
  };
  
  useEffect(() => {
    // Delay slightly to ensure the container is in the DOM
    const timeoutId = setTimeout(() => setupRecaptcha(), 100);
    return () => clearTimeout(timeoutId);
  }, []);

  const handleSendOtp = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    if (!/^\d{10}$/.test(phone)) {
        toast({ variant: "destructive", title: "Invalid Phone Number", description: "Please enter a valid 10-digit phone number." });
        return;
    }
    setLoading(true);
    const fullPhoneNumber = `+91${phone}`;
    const appVerifier = window.recaptchaVerifier;
    
    if (!appVerifier) {
        toast({ variant: "destructive", title: "Error", description: "reCAPTCHA not initialized. Please refresh."});
        setLoading(false);
        return;
    }

    try {
      console.log("Attempting to send OTP to:", fullPhoneNumber);
      const confirmationResult = await signInWithPhoneNumber(auth, fullPhoneNumber, appVerifier);
      window.confirmationResult = confirmationResult;
      setStep("otp");
      toast({
          title: "OTP Sent",
          description: `An OTP has been sent to ${fullPhoneNumber}.`,
      });
    } catch (error: any) {
        console.error("Error sending OTP:", error);
        let description = "An unknown error occurred. Please try again.";
        if (error.code === 'auth/invalid-phone-number') {
            description = "The phone number you entered is not valid.";
        } else if (error.code === 'auth/too-many-requests') {
            description = "You've made too many requests. Please wait a while before trying again.";
        } else if (error.code === 'auth/captcha-check-failed') {
            description = "reCAPTCHA verification failed. Please refresh the page and try again.";
        } else if (error.code === 'auth/invalid-app-credential') {
            description = "App verification failed. Please contact support.";
        } else if (error.code === 'auth/operation-not-allowed') {
            description = "Phone authentication is not enabled. Please contact support.";
        }

        // Reset reCAPTCHA on error
        if (window.recaptchaVerifier) {
          window.recaptchaVerifier.clear();
          window.recaptchaVerifier = undefined as any;
          setTimeout(() => setupRecaptcha(), 1000);
        }

        toast({
            variant: "destructive",
            title: "Failed to Send OTP",
            description: description,
        });
    } finally {
        setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    if (!/^\d{6}$/.test(otp)) {
        toast({ variant: "destructive", title: "Invalid OTP", description: "Please enter a valid 6-digit OTP." });
        return;
    }
    setLoading(true);

    try {
      const result = await window.confirmationResult.confirm(otp);
      const user = result.user;

      if (user && user.phoneNumber) {
        const userProfile = await checkUserExistsByPhone(user.phoneNumber);
        if (userProfile) {
          // User exists, go to dashboard
          toast({ title: "Login Successful!", description: "Welcome back!" });
          router.push("/dashboard");
        } else {
          // New user, go to registration
          toast({ title: "Phone Verified!", description: "Please complete your registration." });
          router.push("/register");
        }
      } else {
         throw new Error("Phone number not available after verification.");
      }

    } catch (error) {
       console.error("Error verifying OTP:", error);
       toast({ variant: "destructive", title: "Login Failed", description: "The OTP you entered is incorrect or has expired." });
       setLoading(false);
    } 
    // Do not set loading to false here, as the redirect will unmount the component
  };
  
  return (
    <div className="grid gap-4">
      <div id="recaptcha-container"></div>
      
      {step === "phone" && (
        <div className="grid gap-2">
          <Label htmlFor="phone">Phone Number</Label>
          <div className="flex items-center">
            <span className="inline-flex items-center px-3 text-sm text-muted-foreground border border-r-0 border-input rounded-l-md bg-muted h-10">
              +91
            </span>
            <Input 
              id="phone" 
              type="tel" 
              placeholder="000-000-0000" 
              required 
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="rounded-l-none"
            />
          </div>
        </div>
      )}

      {step === "otp" && (
        <div className="grid gap-2">
          <Label htmlFor="otp">Enter 6-Digit OTP</Label>
          <Input 
            id="otp" 
            type="text" 
            inputMode="numeric" 
            placeholder="123456" 
            required 
            maxLength={6}
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
          />
        </div>
      )}

      {step === "phone" && (
        <Button onClick={handleSendOtp} disabled={loading} className="w-full bg-accent hover:bg-accent/90">
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Send OTP
        </Button>
      )}

      {step === "otp" && (
        <Button onClick={handleVerifyOtp} disabled={loading} className="w-full">
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Verify & Sign In
        </Button>
      )}
    </div>
  );
}
