
"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { CalendarIcon, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { auth, db } from "@/lib/firebase";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const formSchema = z
  .object({
    fullName: z.string().min(2, "Full name must be at least 2 characters."),
    dob: z.date().optional(),
    email: z.string().email("Please enter a valid email.").optional().or(z.literal("")),
    houseNo: z.string().optional(),
    street: z.string().optional(),
    villageCity: z.string().min(1, "Village/City is required."),
    mandal: z.string().min(1, "Mandal is required."),
    district: z.string().min(1, "District is required."),
    state: z.string().min(1, "State is required."),
    pincode: z.string().optional(),
    pin: z.string().length(6, "PIN must be 6 digits."),
    referralCode: z.string().optional(),
    terms: z.boolean().default(false),
  })
  .refine((data) => data.terms === true, {
    message: "You must accept the terms and conditions.",
    path: ["terms"],
  });

export function RegisterForm() {
  const router = useRouter();
  const { toast } = useToast();

  const [loading, setLoading] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [userPhoneNumber, setUserPhoneNumber] = useState("");

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user && user.phoneNumber) {
        setUserPhoneNumber(user.phoneNumber);
      } else {
        // If no user, they shouldn't be here. Redirect to login.
        router.push("/");
      }
    });
    return () => unsubscribe();
  }, [router]);






  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      houseNo: "",
      street: "",
      villageCity: "",
      mandal: "",
      district: "",
      state: "",
      pincode: "",
      pin: "",
      referralCode: "",
      terms: false,
    },
  });

  const generateReferralCode = (name: string) => {
    const prefix = name.substring(0, 4).toUpperCase().replace(/\s/g, '');
    const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}${randomPart}`;
  };

  const generateMemberId = () => {
    const datePart = format(new Date(), "yyyyMMdd");
    const randomPart = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `MBR-${datePart}-${randomPart}`;
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoading(true);
    const currentUser = auth.currentUser;
    const rootAdminPhone = "+919908024881";

    if (!currentUser || !currentUser.phoneNumber) {
      toast({
        variant: "destructive",
        title: "Authentication Error",
        description: "You are not logged in or your phone number is missing. Please log in again.",
      });
      setLoading(false);
      router.push("/");
      return;
    }

    const isRootAdmin = currentUser.phoneNumber === rootAdminPhone;

    try {
      const newMemberId = generateMemberId();
      const newReferralCode = generateReferralCode(values.fullName);
      
      const userData = {
        uid: currentUser.uid,
        memberId: newMemberId,
        referralCode: newReferralCode,
        referralLink: `https://bss-ind-app.web.app/register?ref=${newReferralCode}`,
        referredBy: values.referralCode || null,
        fullName: values.fullName,
        dob: values.dob ? format(values.dob, "yyyy-MM-dd") : null,
        email: values.email || null,
        phone: currentUser.phoneNumber,
        pin: values.pin,
        address: {
          houseNo: values.houseNo || null,
          street: values.street || null,
          villageCity: values.villageCity,
          mandal: values.mandal,
          district: values.district,
          state: values.state,
          pincode: values.pincode || null,
        },
        // Set role based on phone number
        role: isRootAdmin ? 'Root Administrator' : 'Member',
        currentRoleLevel: isRootAdmin ? 0 : 1,
        directReferrals: 0,
        teamReferrals: 0,
        createdAt: serverTimestamp(),
      };

      // Use the phone number as the document ID
      await setDoc(doc(db, "users", currentUser.phoneNumber), userData);
      
      if(isRootAdmin) {
        toast({
            title: "Root Admin Created!",
            description: "Welcome! Redirecting to your dashboard...",
        });
        router.push("/dashboard");
      } else {
        // Show payment dialog on successful registration for normal users
        setShowPaymentDialog(true);
      }


    } catch (error) {
      console.error("Error creating user profile:", error);
      toast({
        variant: "destructive",
        title: "Registration Failed",
        description: "Could not save your profile. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  }

  const handlePaymentConfirm = () => {
    setShowPaymentDialog(false);
    toast({
      title: "Registration Complete!",
      description: "Welcome to ReferralPro. Redirecting to your dashboard...",
    });
    router.push("/dashboard");
  };

  if (!userPhoneNumber) {
    return <div className="flex justify-center items-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          
          <div className="p-3 rounded-md border bg-muted/50">
            <FormLabel>Phone Number</FormLabel>
            <p className="font-semibold">{userPhoneNumber}</p>
          </div>

          <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Full Name</FormLabel>
                <FormControl>
                  <Input placeholder="John Doe" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <FormField
              control={form.control}
              name="dob"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Date of Birth (Optional)</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) =>
                          date > new Date() || date < new Date("1900-01-01")
                        }
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email (Optional)</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="you@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <p className="font-medium text-sm pt-2">Address Details</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField control={form.control} name="houseNo" render={({ field }) => (
                <FormItem><FormLabel>House No (Optional)</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
            )}/>
             <FormField control={form.control} name="street" render={({ field }) => (
                <FormItem><FormLabel>Street (Optional)</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
            )}/>
            <FormField control={form.control} name="villageCity" render={({ field }) => (
                <FormItem><FormLabel>Village/City</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
            )}/>
             <FormField control={form.control} name="mandal" render={({ field }) => (
                <FormItem><FormLabel>Mandal</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
            )}/>
             <FormField control={form.control} name="district" render={({ field }) => (
                <FormItem><FormLabel>District</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
            )}/>
             <FormField control={form.control} name="state" render={({ field }) => (
                <FormItem><FormLabel>State</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
            )}/>
             <FormField control={form.control} name="pincode" render={({ field }) => (
                <FormItem><FormLabel>Pincode (Optional)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
            )}/>
          </div>

          <FormField
            control={form.control}
            name="pin"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Create 6-Digit PIN</FormLabel>
                <FormControl>
                  <Input type="password" maxLength={6} placeholder="••••••" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="referralCode"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Referral Code (Optional)</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Enter referral code if you have one"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
                <div className="bg-blue-50 border border-blue-200 rounded-md p-3 mt-2">
                  <p className="text-xs text-blue-700 font-medium mb-1">
                    📱 From QR Code or Link?
                  </p>
                  <p className="text-xs text-blue-600">
                    If you scanned a QR code or clicked a referral link, please enter the referral code shown in the URL above (after "ref=").
                  </p>
                </div>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="terms"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 shadow-sm">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>
                    Accept terms and conditions
                  </FormLabel>
                  <FormDescription>
                    You agree to our Terms of Service and Privacy Policy.
                  </FormDescription>
                  <FormMessage />
                </div>
              </FormItem>
            )}
          />
          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Account
          </Button>
        </form>
      </Form>
      
      <AlertDialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Proceed to Payment</AlertDialogTitle>
            <AlertDialogDescription>
              To complete your registration, please pay the one-time membership fee of ₹100.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={handlePaymentConfirm}>
              Pay ₹100 (Mock)
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
