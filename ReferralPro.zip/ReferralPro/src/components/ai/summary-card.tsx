"use client";

import { useEffect, useState } from "react";
import { summarizeReferralData } from "@/ai/flows/summarize-referral-data";
import { Skeleton } from "@/components/ui/skeleton";
import type { User } from "@/lib/types";
import { CardDescription } from "@/components/ui/card";

interface AiSummaryCardProps {
  user: User;
  currentRoleName: string;
  nextRoleDirectReferralsNeeded: number | undefined;
}

export function AiSummaryCard({ user, currentRoleName, nextRoleDirectReferralsNeeded }: AiSummaryCardProps) {
  const [summary, setSummary] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function getSummary() {
      try {
        const result = await summarizeReferralData({
          userName: user.fullName,
          currentRole: currentRoleName,
          directReferrals: user.directReferrals,
          teamReferrals: user.teamReferrals,
          nextRoleThreshold: nextRoleDirectReferralsNeeded || 0,
        });
        setSummary(result.summary);
      } catch (error) {
        console.error("Error fetching summary:", error);
        setSummary("Could not load referral summary at this time.");
      } finally {
        setLoading(false);
      }
    }
    if (user) {
        getSummary();
    }
  }, [user, currentRoleName, nextRoleDirectReferralsNeeded]);

  if (loading) {
    return (
        <div className="space-y-2 mt-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
        </div>
    );
  }

  return <CardDescription>{summary}</CardDescription>;
}
