"use client";

import { useEffect, useState, useTransition } from "react";
import { suggestReferralStrategies } from "@/ai/flows/suggest-referral-strategies";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Wand2, Lightbulb, Loader2 } from "lucide-react";
import type { User } from "@/lib/types";

interface AiStrategiesCardProps {
  user: User;
  currentRoleName: string;
}

export function AiStrategiesCard({ user, currentRoleName }: AiStrategiesCardProps) {
  const [strategies, setStrategies] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [isPending, startTransition] = useTransition();

  const getStrategies = async () => {
    if (!user) return;
    try {
      const result = await suggestReferralStrategies({
        userRole: currentRoleName,
        directReferrals: user.directReferrals,
        teamReferrals: user.teamReferrals,
        networkSize: 1000, // Mock network size
        pastStrategies: "Social media sharing",
      });
      setStrategies(result.strategies);
    } catch (error) {
      console.error("Error fetching strategies:", error);
      setStrategies(["Could not load strategies. Please try again."]);
    } finally {
      setLoading(false);
    }
  };
  
  const handleRegenerate = () => {
    startTransition(async () => {
        setLoading(true);
        await getStrategies();
    });
  }

  useEffect(() => {
    startTransition(async () => {
        await getStrategies();
    });
  }, [user]);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex items-start space-x-4">
          <Skeleton className="h-8 w-8 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-[250px]" />
            <Skeleton className="h-4 w-[200px]" />
          </div>
        </div>
        <div className="flex items-start space-x-4">
          <Skeleton className="h-8 w-8 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-[250px]" />
            <Skeleton className="h-4 w-[200px]" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <ul className="space-y-4 mb-6">
        {strategies.map((strategy, index) => (
          <li key={index} className="flex items-start space-x-3">
            <div className="flex-shrink-0">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Lightbulb className="h-5 w-5" />
              </span>
            </div>
            <p className="text-sm text-foreground">{strategy}</p>
          </li>
        ))}
      </ul>
      <Button onClick={handleRegenerate} disabled={isPending}>
        {isPending ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <Wand2 className="mr-2 h-4 w-4" />
        )}
        Get New Suggestions
      </Button>
    </div>
  );
}
