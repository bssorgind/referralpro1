import { QRCodeSVG } from 'qrcode.react';

interface QrCodeProps {
  value: string;
}

export default function QrCode({ value }: QrCodeProps) {
  return (
    <div className="rounded-lg bg-white p-2 border shadow-sm">
      <QRCodeSVG
        value={value}
        size={120}
        bgColor="#ffffff"
        fgColor="#000000"
        level="M"
        includeMargin={false}
      />
    </div>
  );
}
  