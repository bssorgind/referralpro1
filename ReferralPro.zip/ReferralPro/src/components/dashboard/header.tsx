import { Rocket } from "lucide-react";
import { UserNav } from "./user-nav";
import type { User } from "@/lib/types";

interface DashboardHeaderProps {
  user: User | null;
}

export function DashboardHeader({ user }: DashboardHeaderProps) {
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-card">
      <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
        <div className="flex items-center gap-2">
          <Rocket className="w-6 h-6 text-primary" />
          <h1 className="text-xl font-bold font-headline text-primary">
            ReferralPro
          </h1>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
         {user && <UserNav user={user} />}
        </div>
      </div>
    </header>
  );
}
