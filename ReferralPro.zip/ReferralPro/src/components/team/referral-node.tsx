// src/components/team/referral-node.tsx
"use client";

import { useState, useTransition } from "react";
import { getReferralsByCode } from "@/app/actions";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { User, Users, Loader2, ChevronRight, RefreshCw } from "lucide-react";

interface NodeUser {
  fullName: string;
  role: string;
  referralCode: string;
}

interface ReferralNodeProps {
  user: NodeUser;
  isRoot?: boolean;
}

export function ReferralNode({ user, isRoot = false }: ReferralNodeProps) {
  const [children, setChildren] = useState<NodeUser[]>([]);
  const [isExpanded, setIsExpanded] = useState(isRoot);
  const [wasFetched, setWasFetched] = useState(isRoot);
  const [isPending, startTransition] = useTransition();

  const fetchChildren = (force = false) => {
    if (wasFetched && !force) return; // Don't fetch again if already fetched unless forced
    startTransition(async () => {
      try {
        const result = await getReferralsByCode(user.referralCode);
        setChildren(result);
      } catch (error) {
        console.error("Failed to fetch children:", error);
      } finally {
        setWasFetched(true);
      }
    });
  };

  const refreshChildren = () => {
    setWasFetched(false);
    fetchChildren(true);
  };

  const handleToggle = () => {
    // For root, we fetch immediately. For others, on first expand.
    if (!isRoot && !wasFetched) {
      fetchChildren();
    }
    setIsExpanded(!isExpanded);
  };
  
  // Fetch children for root node on initial render
  useState(() => {
    if (isRoot) {
      fetchChildren();
    }
  });


  const NodeIcon = isRoot ? Users : User;
  const hasChildren = children.length > 0;

  if (isRoot) {
    // Special rendering for the root node, not inside an accordion
     return (
        <div>
            <div className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                <div className="flex items-center">
                    <NodeIcon className="h-5 w-5 mr-3 text-primary" />
                    <span className="font-semibold">{user.fullName}</span>
                    <span className="text-sm text-muted-foreground ml-2">({user.role})</span>
                </div>
                <button
                    onClick={refreshChildren}
                    disabled={isPending}
                    className="p-1 hover:bg-muted rounded-md transition-colors"
                    title="Refresh referrals"
                >
                    <RefreshCw className={`h-4 w-4 text-muted-foreground ${isPending ? 'animate-spin' : ''}`} />
                </button>
            </div>
             <div className="pl-6 mt-2 border-l-2 border-dashed border-border">
                {isPending && <Loader2 className="h-5 w-5 animate-spin my-2" />}
                {!isPending && children.map((child) => (
                    <ReferralNode key={child.referralCode} user={child} />
                ))}
                {wasFetched && !isPending && !hasChildren && (
                     <p className="text-sm text-muted-foreground py-2 italic">No referrals yet.</p>
                )}
             </div>
        </div>
     );
  }

  // Render leaf node (no children to fetch/display)
  if (!wasFetched && !isPending && !hasChildren && children.length === 0 && user.referralCode === '') {
     return (
        <div className="flex items-center py-2 pl-4">
             <User className="h-4 w-4 mr-3 text-muted-foreground" />
             <span className="font-medium">{user.fullName}</span>
             <span className="text-sm text-muted-foreground ml-2">({user.role})</span>
        </div>
     )
  }

  return (
    <Accordion
      type="single"
      collapsible
      className="w-full"
      onValueChange={(value) => {
        if (value && !wasFetched) {
          fetchChildren();
        }
      }}
    >
      <AccordionItem value={user.referralCode} className="border-b-0">
        <AccordionTrigger className="hover:no-underline py-2 hover:bg-muted/50 rounded-md px-2">
           <div className="flex items-center">
            <NodeIcon className="h-5 w-5 mr-3 text-primary" />
            <span className="font-semibold">{user.fullName}</span>
            <span className="text-sm text-muted-foreground ml-2">({user.role})</span>
          </div>
        </AccordionTrigger>
        <AccordionContent className="pl-6 border-l-2 border-dashed border-border">
          {isPending && <Loader2 className="h-5 w-5 animate-spin my-2" />}
          
          {!isPending && children.map((child) => (
            <ReferralNode key={child.referralCode} user={child} />
          ))}

          {wasFetched && !isPending && !hasChildren && (
             <p className="text-sm text-muted-foreground py-2 italic ml-4">No referrals yet.</p>
          )}

        </AccordionContent>
      </AccordionItem>
    </Accordion>
  );
}
