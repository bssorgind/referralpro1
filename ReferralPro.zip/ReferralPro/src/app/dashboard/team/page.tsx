// src/app/dashboard/team/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { doc, getDoc } from "firebase/firestore";
import { useRouter } from "next/navigation";
import { auth, db } from "@/lib/firebase";
import type { User } from "@/lib/types";
import { DashboardHeader } from "@/components/dashboard/header";
import { Loader2, Users } from "lucide-react";
import { ReferralNode } from "@/components/team/referral-node";

export default function TeamPage() {
  const [user, loadingAuth] = useAuthState(auth);
  const [userData, setUserData] = useState<User | null>(null);
  const [loadingData, setLoadingData] = useState(true);
  const router = useRouter();

  useEffect(() => {
    if (loadingAuth) return;
    if (!user) {
      router.push("/");
      return;
    }

    const fetchUserData = async () => {
      if (!user.phoneNumber) {
        router.push("/");
        return;
      }
      try {
        const userDocRef = doc(db, "users", user.phoneNumber);
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
          setUserData(userDoc.data() as User);
        } else {
          router.push("/register");
        }
      } catch (err) {
        console.error("Error fetching user data:", err);
      } finally {
        setLoadingData(false);
      }
    };

    fetchUserData();
  }, [user, loadingAuth, router]);

  if (loadingAuth || loadingData) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!userData) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Could not load user data.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <DashboardHeader user={userData} />
      <main className="flex-1 p-4 sm:p-6 lg:p-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <Users className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold font-headline">Your Team Tree</h1>
          </div>
          <p className="mb-8 text-muted-foreground">
            Here is a visualization of your referral network. You can expand each
            member to see who they have referred.
          </p>
          <div className="border rounded-lg p-4 bg-card">
             <ReferralNode
                user={{
                    fullName: userData.fullName,
                    role: userData.role,
                    referralCode: userData.referralCode,
                }}
                isRoot={true}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
