
"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { doc, getDoc } from "firebase/firestore";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth, db } from "@/lib/firebase";
import type { User } from "@/lib/types";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { ROLES } from "@/lib/data";
import { DashboardHeader } from "@/components/dashboard/header";
import {
  Copy,
  Download,
  Share2,
  Users,
  UserCheck,
  Loader2,
  Check,
  Crown,
} from "lucide-react";
import QrCode from "@/components/dashboard/qr-code";
import { AiSummaryCard } from "@/components/ai/summary-card";
import { AiStrategiesCard } from "@/components/ai/strategies-card";
import { useToast } from "@/hooks/use-toast";

export default function DashboardPage() {
  const [user, loadingAuth, error] = useAuthState(auth);
  const [userData, setUserData] = useState<User | null>(null);
  const [loadingData, setLoadingData] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const router = useRouter();
  const { toast } = useToast();
  const qrCodeRef = useRef<HTMLDivElement>(null);


  useEffect(() => {
    if (loadingAuth) return;
    if (!user) {
      router.push("/");
      return;
    }
    // Ensure we have the phone number to fetch data
    if (!user.phoneNumber) {
        console.error("User is authenticated but phone number is missing.");
        router.push("/"); // Or a logout action
        return;
    }

    const fetchUserData = async () => {
      try {
        // Use the phone number as the document ID
        const userDocRef = doc(db, "users", user.phoneNumber!);
        const userDoc = await getDoc(userDocRef);

        if (userDoc.exists()) {
          setUserData(userDoc.data() as User);
        } else {
          // This case might happen if login redirects here before registration is complete
          console.error("No user data found in Firestore, redirecting to register.");
          router.push("/register");
        }
      } catch (err) {
        console.error("Error fetching user data:", err);
        toast({ variant: 'destructive', title: 'Error', description: 'Could not load your data.' });
      } finally {
        setLoadingData(false);
      }
    };

    fetchUserData();
  }, [user, loadingAuth, router, toast]);

  const handleCopy = (text: string, type: "link" | "code") => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard!" });
    if (type === "link") {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } else {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleShare = async () => {
    if (navigator.share && userData) {
      try {
        await navigator.share({
          title: "Join me on ReferralPro!",
          text: `Join my team on ReferralPro using my referral code: ${userData.referralCode}`,
          url: userData.referralLink,
        });
      } catch (error) {
        console.error("Error sharing:", error);
      }
    } else {
      toast({
        variant: "destructive",
        title: "Share not supported",
        description: "Your browser does not support the Web Share API.",
      });
    }
  };

  const handleDownload = () => {
    if (qrCodeRef.current) {
        const svgElement = qrCodeRef.current.querySelector('svg');
        if (svgElement) {
            const serializer = new XMLSerializer();
            const svgString = serializer.serializeToString(svgElement);
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const img = new Image();
            
            img.onload = () => {
                if (ctx) {
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0);
                    const pngUrl = canvas.toDataURL('image/png');
                    const link = document.createElement('a');
                    link.href = pngUrl;
                    link.download = 'referral-qr-code.png';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            };
            
            img.src = 'data:image/svg+xml;base64,' + btoa(svgString);
        }
    }
  };


  if (loadingAuth || loadingData) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!userData) {
     // This can be a more user-friendly error page or redirect
     return (
        <div className="flex items-center justify-center min-h-screen">
            <p>Could not load user data. Please try logging in again.</p>
            <Button onClick={() => router.push('/')} className="ml-4">Login</Button>
        </div>
    );
  }

  const currentRole = ROLES.find(
    (role) => role.level === userData.currentRoleLevel
  );
  const nextRole = ROLES.find(
    (role) => role.level === userData.currentRoleLevel + 1
  );

  const progress =
    nextRole && nextRole.directReferralsNeeded > 0 && nextRole.directReferralsNeeded !== Infinity
      ? Math.round(
          (userData.directReferrals / nextRole.directReferralsNeeded) * 100
        )
      : 100;

  if (!currentRole) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4">Error: User role not found.</p>
      </div>
    );
  }

  const isAdmin = userData.currentRoleLevel === 0;

  return (
    <div className="flex flex-col min-h-screen">
      <DashboardHeader user={userData} />
      <main className="flex-1 p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Welcome Card */}
          <Card className="lg:col-span-4 shadow-lg">
            <CardHeader>
              <CardTitle className="font-headline text-2xl">
                Welcome, {userData.fullName}!
              </CardTitle>
              {!isAdmin && <AiSummaryCard
                user={userData}
                currentRoleName={currentRole.name}
                nextRoleDirectReferralsNeeded={nextRole?.directReferralsNeeded}
              />}
              {isAdmin && <CardDescription>You are the Root Administrator. Manage the platform from here.</CardDescription>}
            </CardHeader>
          </Card>

          {/* Stats Cards */}
          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">
                Direct Referrals
              </CardTitle>
              <UserCheck className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{userData.directReferrals}</div>
              <p className="text-xs text-muted-foreground">
                New members you invited
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">
                Team Referrals
              </CardTitle>
              <Users className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{userData.teamReferrals}</div>
              <p className="text-xs text-muted-foreground">
                Total members in your downline
              </p>
            </CardContent>
          </Card>

          {/* Progress Card */}
          {nextRole && !isAdmin && (
            <Card className="lg:col-span-2 shadow-lg">
              <CardHeader>
                <CardTitle className="font-headline text-lg">
                  Your Next Promotion
                </CardTitle>
                <CardDescription>
                  You are on your way to becoming a {nextRole.name}!
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-muted-foreground">
                    {currentRole.name}
                  </span>
                  <span className="text-sm font-medium text-muted-foreground">
                    {nextRole.name}
                  </span>
                </div>
                <Progress value={progress} className="h-3" />
                <p className="text-center mt-2 text-sm font-semibold">
                  {userData.directReferrals} / {nextRole.directReferralsNeeded}{" "}
                  direct referrals
                </p>
              </CardContent>
            </Card>
          )}

          {isAdmin && (
            <Card className="lg:col-span-2 shadow-lg bg-primary/5 border-primary">
                 <CardHeader>
                    <CardTitle className="font-headline text-lg flex items-center gap-2">
                        <Crown className="text-primary"/> Root Administrator
                    </CardTitle>
                    <CardDescription>
                        You have the highest level of access.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                   <p className="text-sm text-muted-foreground">Admin-specific controls and analytics will be displayed here.</p>
                </CardContent>
            </Card>
          )}

          {/* Share Card */}
          <Card className="lg:col-span-2 shadow-lg">
            <CardHeader>
              <CardTitle className="font-headline text-lg">
                Share Your Code
              </CardTitle>
              <CardDescription>
                Invite others and grow your team.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col md:flex-row items-center gap-6">
              <div className="flex-1 w-full">
                <p className="text-sm font-semibold mb-2">
                  Your Referral Link
                </p>
                <div className="flex items-center gap-2">
                  <Input readOnly value={userData.referralLink} />
                  <Button variant="outline" size="icon" onClick={() => handleCopy(userData.referralLink, "link")}>
                    {copiedLink ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
                <Separator className="my-4" />
                <p className="text-sm font-semibold mb-2">Your Unique Code</p>
                <div className="flex items-center gap-2">
                  <Input
                    readOnly
                    value={userData.referralCode}
                    className="font-mono tracking-widest text-center bg-muted"
                  />
                  <Button variant="outline" size="icon" onClick={() => handleCopy(userData.referralCode, "code")}>
                    {copiedCode ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <div className="flex flex-col items-center gap-2">
                <div ref={qrCodeRef}>
                    <QrCode value={userData.referralLink} />
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={handleShare}>
                    <Share2 className="mr-2 h-4 w-4" /> Share
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDownload}>
                    <Download className="mr-2 h-4 w-4" /> Download
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Strategies Card */}
          {!isAdmin && <Card className="lg:col-span-4 shadow-lg">
            <CardHeader>
              <CardTitle className="font-headline text-lg">
                Personalized Strategies
              </CardTitle>
              <CardDescription>
                AI-powered tips to help you reach the next level.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AiStrategiesCard user={userData} currentRoleName={currentRole.name} />
            </CardContent>
          </Card>}
        </div>
      </main>
    </div>
  );
}
