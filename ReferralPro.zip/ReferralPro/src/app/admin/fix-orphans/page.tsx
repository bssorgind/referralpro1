
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { fixOrphanedUsers } from './actions';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

export default function FixOrphansPage() {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{ updatedCount: number; error?: string } | null>(null);
  const { toast } = useToast();

  const handleFixUsers = async () => {
    setLoading(true);
    setResults(null);
    try {
      const result = await fixOrphanedUsers();
      setResults(result);
      if (result.error) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: result.error,
        });
      } else {
        toast({
          title: 'Success!',
          description: `Updated ${result.updatedCount} orphaned users.`,
        });
      }
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setResults({ updatedCount: 0, error: errorMessage });
      toast({
        variant: 'destructive',
        title: 'An unexpected error occurred',
        description: errorMessage,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <CardTitle>Fix Orphaned Users</CardTitle>
          <CardDescription>
            This is a one-time action to fix existing users in the database who have no referrer. It will assign them to the root admin ('ADMIN').
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center gap-4">
            <p className="text-sm text-muted-foreground">Click the button below to start the process.</p>
            <Button onClick={handleFixUsers} disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {loading ? 'Processing...' : 'Assign ADMIN to Orphaned Users'}
            </Button>
            {results && (
              <div className="mt-4 text-center">
                {results.error ? (
                  <p className="text-destructive">Error: {results.error}</p>
                ) : (
                  <p className="text-primary">{`Successfully updated ${results.updatedCount} user(s).`}</p>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
