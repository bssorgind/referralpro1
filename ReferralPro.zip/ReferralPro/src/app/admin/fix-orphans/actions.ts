
'use server';

import { initializeAdminApp } from '@/lib/firebase-admin';
import { getFirestore, WriteBatch } from 'firebase-admin/firestore';

/**
 * Finds all users where 'referredBy' is null and updates it to 'ADMIN'.
 * This is a one-time script to fix existing orphaned data.
 */
export async function fixOrphanedUsers(): Promise<{ updatedCount: number; error?: string }> {
  try {
    const adminApp = initializeAdminApp();
    if (!adminApp) {
      throw new Error('Firebase Admin SDK failed to initialize. Check server logs for details.');
    }
    const db = getFirestore(adminApp);
    const usersRef = db.collection('users');

    // Find all users with referredBy === null
    const snapshot = await usersRef.where('referredBy', '==', null).get();

    if (snapshot.empty) {
      console.log('No orphaned users found.');
      return { updatedCount: 0 };
    }

    const batches: WriteBatch[] = [];
    let currentBatch = db.batch();
    let writeCount = 0;
    let totalUpdatedCount = 0;

    snapshot.docs.forEach((doc) => {
      // Do not modify the root admin itself if it was created without a referrer
      if (doc.data().role === 'Root Administrator' || doc.data().referralCode === 'ADMIN') {
        return;
      }

      currentBatch.update(doc.ref, { referredBy: 'ADMIN' });
      writeCount++;
      totalUpdatedCount++;

      // Firestore batches can have a maximum of 500 operations.
      if (writeCount === 499) {
        batches.push(currentBatch);
        currentBatch = db.batch();
        writeCount = 0;
      }
    });

    // Add the last batch if it has any operations
    if (writeCount > 0) {
      batches.push(currentBatch);
    }
    
    // Commit all batches
    await Promise.all(batches.map((batch) => batch.commit()));

    console.log(`Successfully updated ${totalUpdatedCount} orphaned users.`);
    return { updatedCount: totalUpdatedCount };
  } catch (error) {
    console.error('Error fixing orphaned users:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
    return { updatedCount: 0, error: errorMessage };
  }
}
