
'use server';

import { getFirestore } from 'firebase-admin/firestore';
import { initializeAdminApp } from '@/lib/firebase-admin';

// This file is kept for potential future server actions.
// The signInWithPin function has been removed as part of the simplification
// to a standard OTP-based login flow.

/**
 * Fetches the direct referrals for a given referral code.
 * @param referralCode The referral code of the parent user.
 * @returns A promise that resolves to an array of simplified user objects.
 */
export async function getReferralsByCode(referralCode: string): Promise<
  { fullName: string; role: string; referralCode: string }[]
> {
  try {
    console.log(`🔍 Searching for users with referredBy = "${referralCode}"`);
    const adminDb = getFirestore(initializeAdminApp());
    const usersRef = adminDb.collection('users');
    const q = usersRef.where('referredBy', '==', referralCode);
    const querySnapshot = await q.get();

    console.log(`📊 Query returned ${querySnapshot.size} documents`);

    if (querySnapshot.empty) {
      console.log(`❌ No users found with referredBy = "${referralCode}"`);
      return [];
    }

    const referrals = querySnapshot.docs.map(doc => {
      const data = doc.data();
      console.log(`✅ Found referral: ${data.fullName} (referredBy: ${data.referredBy})`);
      return {
        fullName: data.fullName || 'N/A',
        role: data.role || 'Member',
        referralCode: data.referralCode || '',
      };
    });

    return referrals;
  } catch (error) {
    console.error('❌ Error fetching referrals:', error);
    // In a real app, you might want to handle this more gracefully
    return [];
  }
}

