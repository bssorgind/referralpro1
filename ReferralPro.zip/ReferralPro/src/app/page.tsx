
"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth } from "@/lib/firebase";
import { LoginForm } from "@/components/auth/login-form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Rocket, Loader2 } from "lucide-react";

export default function Home() {
  const [user, loading] = useAuthState(auth);
  const router = useRouter();

  useEffect(() => {
    // If the auth state is done loading and we have a user, redirect to the dashboard.
    if (!loading && user) {
      router.push("/dashboard");
    }
  }, [user, loading, router]);

  // While checking for the user's session, show a loading screen.
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  // If there's no user after loading, show the login page.
  if (!user) {
    return (
      <main className="flex flex-col items-center justify-center min-h-screen p-4">
        <div className="flex items-center gap-2 mb-8">
          <Rocket className="w-8 h-8 text-primary" />
          <h1 className="text-3xl font-bold font-headline text-primary">
            ReferralPro
          </h1>
        </div>
        <Card className="w-full max-w-sm shadow-xl">
          <CardHeader>
            <CardTitle className="font-headline">Welcome Back</CardTitle>
            <CardDescription>Enter your phone number to sign in.</CardDescription>
          </CardHeader>
          <CardContent>
            <LoginForm />
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-muted-foreground">
              Don&apos;t have an account?{" "}
              <Link href="/register" className="font-semibold text-primary hover:underline">
                Sign up
              </Link>
            </p>
          </CardFooter>
        </Card>
      </main>
    );
  }

  // This will be shown briefly during the redirect if the user is logged in.
  // Can also be a loading component.
  return (
    <div className="flex items-center justify-center min-h-screen">
      <Loader2 className="h-12 w-12 animate-spin text-primary" />
    </div>
  );
}
