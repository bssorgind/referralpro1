# ReferralPro

A Next.js web application built with Firebase that implements a multi-level referral system with automated role promotions. The platform allows users to build teams through referrals and advance through a hierarchical role structure.

## 🚀 Features

- **Phone-based Authentication** using Firebase Auth
- **Referral System** with unique codes and QR code sharing
- **Hierarchical Role Structure** with 8 levels (Member → State Coordinator)
- **Real-time Dashboard** showing referral statistics and progress
- **AI-powered Insights** for personalized growth strategies
- **Automated Role Promotions** based on referral thresholds

## 🛠️ Tech Stack

- **Frontend**: Next.js 15, React, TypeScript, Tailwind CSS
- **Backend**: Firebase (Auth, Firestore, Functions)
- **UI Components**: Radix UI with shadcn/ui
- **AI Integration**: Google Genkit for personalized recommendations

## 📋 Prerequisites

- Node.js 18+ and npm
- Firebase CLI
- Firebase project with Authentication and Firestore enabled

## ⚙️ Setup Instructions

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd ReferralPro
```

### 2. Install Dependencies

```bash
npm install
cd functions
npm install
cd ..
```

### 3. Firebase Configuration

1. Create a Firebase project at [Firebase Console](https://console.firebase.google.com/)
2. Enable Authentication (Phone method)
3. Create Firestore Database
4. Copy your Firebase config and create `.env.local`:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
GOOGLE_GENAI_API_KEY=your_google_ai_key
```

### 4. Firebase Setup

```bash
# Login to Firebase
firebase login

# Initialize Firebase (if not already done)
firebase init

# Deploy functions and rules
firebase deploy
```

### 5. Initialize Database

Visit the setup function URL to create sample data:
```
https://your-region-your-project.cloudfunctions.net/setupDatabase
```

### 6. Run Development Server

```bash
npm run dev
```

Open [http://localhost:9002](http://localhost:9002) to view the application.

## 🏗️ Role Hierarchy

Users progress through 8 levels based on referrals:

1. **Member** (Level 1) - Starting level
2. **Volunteer** (Level 2) - 10+ direct referrals
3. **Team Leader** (Level 3) - 100+ team members
4. **Area Coordinator** (Level 4) - 1,000+ team members
5. **District Coordinator** (Level 5) - 10,000+ team members
6. **Regional Coordinator** (Level 6) - 100,000+ team members
7. **Zonal Coordinator** (Level 7) - 1,000,000+ team members
8. **State Coordinator** (Level 8) - 10,000,000+ team members

## 🔧 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

## 📱 Testing

### Test Phone Numbers

Add these in Firebase Console → Authentication → Phone → Test numbers:

- `+919876543210` → `123456` (Admin)
- `+919876543211` → `123456` (Sample User)

## 🚀 Deployment

The app is configured for Firebase Hosting:

```bash
npm run build
firebase deploy
```

## 📄 License

This project is licensed under the MIT License.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request
