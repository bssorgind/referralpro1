const admin = require('firebase-admin');

// Initialize Firebase Admin SDK using Application Default Credentials
// This works when running in Firebase environment or with GOOGLE_APPLICATION_CREDENTIALS
admin.initializeApp({
  projectId: 'bss-ind-app'
});

const db = admin.firestore();

// Sample users data
const sampleUsers = [
  {
    phone: '+919876543210',
    data: {
      uid: 'admin',
      fullName: 'Root Administrator',
      memberId: 'ADMIN001',
      referralCode: 'ADMIN',
      referralLink: 'https://bss-ind-app.web.app/register?ref=ADMIN',
      referredBy: null,
      dob: null,
      email: 'admin@referralpro.com',
      phone: '+919876543210',
      pin: '0000',
      address: {
        houseNo: null,
        street: null,
        villageCity: 'Admin City',
        mandal: 'Admin Mandal',
        district: 'Admin District',
        state: 'Admin State',
        pincode: null
      },
      role: 'Root Administrator',
      currentRoleLevel: 0,
      directReferrals: 5,
      teamReferrals: 25,
      createdAt: admin.firestore.Timestamp.now()
    }
  },
  {
    phone: '+919876543211',
    data: {
      uid: 'user1',
      fullName: 'Rajesh Kumar',
      memberId: 'REF001',
      referralCode: 'RAJ2024',
      referralLink: 'https://bss-ind-app.web.app/register?ref=RAJ2024',
      referredBy: 'ADMIN',
      dob: '1990-05-15',
      email: 'rajesh@example.com',
      phone: '+919876543211',
      pin: '1234',
      address: {
        houseNo: '123',
        street: 'MG Road',
        villageCity: 'Hyderabad',
        mandal: 'Secunderabad',
        district: 'Hyderabad',
        state: 'Telangana',
        pincode: '500001'
      },
      role: 'Volunteer',
      currentRoleLevel: 2,
      directReferrals: 12,
      teamReferrals: 45,
      createdAt: admin.firestore.Timestamp.now()
    }
  },
  {
    phone: '+919876543212',
    data: {
      uid: 'user2',
      fullName: 'Priya Sharma',
      memberId: 'REF002',
      referralCode: 'PRI2024',
      referralLink: 'https://bss-ind-app.web.app/register?ref=PRI2024',
      referredBy: 'RAJ2024',
      dob: '1992-08-22',
      email: 'priya@example.com',
      phone: '+919876543212',
      pin: '5678',
      address: {
        houseNo: '456',
        street: 'Jubilee Hills',
        villageCity: 'Hyderabad',
        mandal: 'Jubilee Hills',
        district: 'Hyderabad',
        state: 'Telangana',
        pincode: '500033'
      },
      role: 'Member',
      currentRoleLevel: 1,
      directReferrals: 3,
      teamReferrals: 8,
      createdAt: admin.firestore.Timestamp.now()
    }
  },
  {
    phone: '+919876543213',
    data: {
      uid: 'user3',
      fullName: 'Amit Patel',
      memberId: 'REF003',
      referralCode: 'AMI2024',
      referralLink: 'https://bss-ind-app.web.app/register?ref=AMI2024',
      referredBy: 'RAJ2024',
      dob: '1988-12-10',
      email: 'amit@example.com',
      phone: '+919876543213',
      pin: '9012',
      address: {
        houseNo: '789',
        street: 'Banjara Hills',
        villageCity: 'Hyderabad',
        mandal: 'Banjara Hills',
        district: 'Hyderabad',
        state: 'Telangana',
        pincode: '500034'
      },
      role: 'Team Leader',
      currentRoleLevel: 3,
      directReferrals: 8,
      teamReferrals: 150,
      createdAt: admin.firestore.Timestamp.now()
    }
  },
  {
    phone: '+919876543214',
    data: {
      uid: 'user4',
      fullName: 'Sunita Reddy',
      memberId: 'REF004',
      referralCode: 'SUN2024',
      referralLink: 'https://bss-ind-app.web.app/register?ref=SUN2024',
      referredBy: 'PRI2024',
      dob: '1995-03-18',
      email: 'sunita@example.com',
      phone: '+919876543214',
      pin: '3456',
      address: {
        houseNo: '321',
        street: 'Gachibowli',
        villageCity: 'Hyderabad',
        mandal: 'Serilingampally',
        district: 'Hyderabad',
        state: 'Telangana',
        pincode: '500032'
      },
      role: 'Member',
      currentRoleLevel: 1,
      directReferrals: 2,
      teamReferrals: 2,
      createdAt: admin.firestore.Timestamp.now()
    }
  }
];

async function createUsersDatabase() {
  console.log('🚀 Starting database setup...');

  try {
    // Create users collection with sample data
    const batch = db.batch();

    sampleUsers.forEach(user => {
      const userRef = db.collection('users').doc(user.phone);
      batch.set(userRef, user.data);
    });

    await batch.commit();
    console.log('✅ Successfully created users database with sample data!');

    // Display created users
    console.log('\n📊 Created Users:');
    console.log('================');
    sampleUsers.forEach(user => {
      console.log(`📱 ${user.data.fullName} (${user.phone})`);
      console.log(`   Role: ${user.data.role} (Level ${user.data.currentRoleLevel})`);
      console.log(`   Referral Code: ${user.data.referralCode}`);
      console.log(`   Direct Referrals: ${user.data.directReferrals}`);
      console.log(`   Team Referrals: ${user.data.teamReferrals}`);
      console.log('');
    });

    console.log('🎉 Database setup complete!');
    console.log('\n🔑 Admin Login Details:');
    console.log('Phone: +919876543210');
    console.log('Verification Code: 123456 (if using test number)');

  } catch (error) {
    console.error('❌ Error creating database:', error);
  }
}

createUsersDatabase().then(() => {
  console.log('✨ Setup finished successfully!');
  process.exit(0);
}).catch(error => {
  console.error('💥 Setup failed:', error);
  process.exit(1);
});
