# **App Name**: ReferralPro

## Core Features:

- Phone Authentication: Implement phone number verification using Firebase Auth for secure authentication.
- Registration Form: Design and implement a registration form to collect user data, including name, date of birth, address, and PIN.
- Referral Code Generation: Enable automatic generation of unique referral codes for each user upon registration.
- Referral Sharing: Allow users to share referral links and QR codes via various platforms, making it easy to invite new members.
- Referral Statistics: Display real-time referral statistics, including direct and total team referrals, to keep users informed of their progress.
- Automated Role Promotion: Implement automated role promotion based on referral count thresholds using Firebase's serverless functions. The AI tool should analyze the direct and team referrals count to determine if a member qualifies for the promotion and reflect the change to all relevant members. 
- Referral Dashboard: Develop an interactive dashboard that showcases a user’s current role, referral stats, and progress towards the next role promotion.

## Style Guidelines:

- Primary color: Deep blue (#1E3A8A), reflecting trust and professionalism.
- Background color: Very light blue (#F0F9FF), offering a clean, modern backdrop.
- Accent color: Bright orange (#EA580C), used sparingly to highlight important actions.
- Font pairing: 'Poppins' (sans-serif) for headlines and 'PT Sans' (sans-serif) for body text.
- Use clear and concise icons to represent different user roles and referral statuses.
- Maintain a clean, grid-based layout for the dashboard to ensure readability and usability.
- Use subtle animations to indicate progress in referral count and role promotion.