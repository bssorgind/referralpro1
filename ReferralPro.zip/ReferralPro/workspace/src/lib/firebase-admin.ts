
import * as admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';

// These variables are now read from the single root .env file
const privateKey = process.env.FIREBASE_ADMIN_PRIVATE_KEY;
const clientEmail = process.env.FIREBASE_ADMIN_CLIENT_EMAIL;
const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;

// Ensure all required environment variables are present.
if (!privateKey || !clientEmail || !projectId) {
  console.error('Missing Firebase Admin SDK credentials in environment variables.');
  // In a real app, you might throw an error or handle this more gracefully.
  // For now, we log the error to avoid crashing the server during build.
}

const serviceAccount: admin.ServiceAccount = {
  projectId,
  clientEmail,
  // The value from .env is already a string with newlines, no need for replace
  privateKey: privateKey || '',
};

export const initializeAdminApp = () => {
  if (admin.apps.length === 0 && privateKey) { // Only initialize if credentials exist
    try {
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
      });
      console.log('Firebase Admin SDK initialized successfully.');
    } catch (error) {
      console.error('Error initializing Firebase Admin SDK:', error);
      // Avoid throwing an error that could crash the server during development hot-reloads
    }
  }
  return admin.apps.length > 0 ? admin.app() : null;
};

export const getAdminDb = () => {
    initializeAdminApp();
    return getFirestore();
}
