/**
 * Import function triggers from their respective submodules:
 *
 * import {onCall} from "firebase-functions/v2/https";
 * import {onDocumentWritten} from "firebase-functions/v2/firestore";
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

import { onDocumentCreated, onDocumentUpdated } from "firebase-functions/v2/firestore";
import { onRequest } from "firebase-functions/v2/https";
import * as logger from "firebase-functions/logger";
import * as admin from "firebase-admin";

// Initialize the Admin SDK. When deployed, it will automatically use the project's service account.
admin.initializeApp();
const db = admin.firestore();

// Role thresholds - must be in descending order of requirements
const ROLE_THRESHOLDS = [
  { level: 8, name: "State Coordinator", direct: 0, team: 10000000 },
  { level: 7, name: "District Coordinator", direct: 0, team: 1000000 },
  { level: 6, name: "Constituency Coordinator", direct: 0, team: 100000 },
  { level: 5, name: "Mandal Coordinator", direct: 0, team: 10000 },
  { level: 4, name: "Area Coordinator", direct: 0, team: 1000 },
  { level: 3, name: "Team Leader", direct: 0, team: 100 },
  { level: 2, name: "Volunteer", direct: 10, team: 0 },
  { level: 1, name: "Member", direct: 0, team: 0 },
];


// This function triggers when a new user document is created in Firestore.
export const processReferral = onDocumentCreated("users/{userId}", async (event) => {
    const snapshot = event.data;
    if (!snapshot) {
      logger.log("No data associated with the event");
      return;
    }
    const newUserDocRef = snapshot.ref;
    const newUser = snapshot.data();
    let referredByCode = newUser.referredBy; // This is the referral code of the referrer

    logger.log(`🔍 NEW USER REGISTRATION DEBUG:`);
    logger.log(`   User: ${newUser.fullName} (${snapshot.id})`);
    logger.log(`   Phone: ${newUser.phone}`);
    logger.log(`   Original referredBy: "${referredByCode}"`);
    logger.log(`   Is referredBy empty/null? ${!referredByCode}`);

    // If there's no referral code, assign the user to the root admin.
    if (!referredByCode) {
        logger.log(`❌ User ${newUser.fullName} was not referred. Assigning to root admin.`);
        const adminReferralCode = "ADMIN";

        // Update the new user's document with the admin's referral code.
        await newUserDocRef.update({ referredBy: adminReferralCode });
        // CRITICAL FIX: Update the local variable to continue processing with the new code.
        referredByCode = adminReferralCode;
        logger.log(`✅ Assigned user ${newUser.fullName} to root admin with code ${adminReferralCode}`);
    } else {
        logger.log(`✅ User ${newUser.fullName} has valid referral code: "${referredByCode}"`);
    }

    // This block now runs for all users, including those just assigned to the root admin.
    if (referredByCode) {
        logger.log(`Processing referral for ${newUser.fullName}. Referred by code: ${referredByCode}`);

        const usersRef = db.collection("users");
        let currentReferrerCode = referredByCode;
        let isDirectReferral = true;
        const batch = db.batch();

        try {
            // Loop to traverse up the referral chain.
            while (currentReferrerCode) {
                const referrerQuery = usersRef.where("referralCode", "==", currentReferrerCode).limit(1);
                const referrerSnapshot = await referrerQuery.get();

                if (referrerSnapshot.empty) {
                    logger.warn(`Referrer with code ${currentReferrerCode} not found. Stopping chain.`);
                    break; // Exit loop if a referrer is not found
                }

                const referrerDoc = referrerSnapshot.docs[0];
                const referrerDocRef = referrerDoc.ref;
                const referrerData = referrerDoc.data();

                logger.log(`Found referrer: ${referrerData.fullName} (${referrerDoc.id})`);

                if (isDirectReferral) {
                    // The first user in the chain is the direct referrer.
                    // Increment both direct and team referrals.
                    batch.update(referrerDocRef, {
                        directReferrals: admin.firestore.FieldValue.increment(1),
                        teamReferrals: admin.firestore.FieldValue.increment(1)
                    });
                    logger.log(`Credited direct referral to ${referrerData.fullName} (${currentReferrerCode})`);
                    isDirectReferral = false; // Subsequent referrers are upline
                } else {
                    // For upline members, only increment team referrals.
                    batch.update(referrerDocRef, {
                        teamReferrals: admin.firestore.FieldValue.increment(1)
                    });
                    logger.log(`Credited team referral to ${referrerData.fullName} (${currentReferrerCode})`);
                }

                // Stop processing if we reach the admin (admin has no upline)
                if (currentReferrerCode === "ADMIN") {
                    logger.log("Reached ADMIN code. Stopping chain traversal after crediting admin.");
                    break;
                }

                // Move to the next person up the chain
                currentReferrerCode = referrerData.referredBy;
            }

            // Commit all the updates in a single batch operation.
            await batch.commit();
            logger.log("Successfully credited referrals up the chain.");

        } catch (error) {
            logger.error("Error processing referral chain:", error);
        }
    }
});


// This function triggers whenever a user's referral counts are updated.
export const autoPromoteUser = onDocumentUpdated("users/{userId}", async (event) => {
    const change = event.data;
    if (!change) return;

    const userData = change.after.data();
    const beforeData = change.before.data();

    // Check if referral counts have actually changed to prevent infinite loops
    if (
        userData.directReferrals === beforeData.directReferrals &&
        userData.teamReferrals === beforeData.teamReferrals
    ) {
        return;
    }
    
    // Ignore root admin from promotions
    if (userData.currentRoleLevel === 0) {
        return;
    }

    const { directReferrals, teamReferrals, currentRoleLevel } = userData;

    let newRole = { level: 1, name: "Member" }; // Default role

    // Iterate through thresholds to find the highest eligible role
    for (const role of ROLE_THRESHOLDS) {
        const meetsDirect = directReferrals >= role.direct;
        const meetsTeam = teamReferrals >= role.team;

        // For most roles, only team size matters after Volunteer
        if (role.level > 2) {
             if (meetsTeam) {
                newRole = role;
                break; // Found the highest role
             }
        } else { // For Volunteer and Member, check direct referrals
            if (meetsDirect) {
                newRole = role;
                break;
            }
        }
    }
    
    // If the user's role has changed, update their document
    if (newRole.level > currentRoleLevel) {
        logger.log(`Promoting user ${event.params.userId} from level ${currentRoleLevel} to ${newRole.level} (${newRole.name}).`);
        await change.after.ref.update({
            currentRoleLevel: newRole.level,
            role: newRole.name,
        });
    }
});

// HTTP function to setup initial database with sample data
export const setupDatabase = onRequest(async (req, res) => {
    try {
        // Check if database already has users
        const usersSnapshot = await db.collection('users').limit(1).get();
        if (!usersSnapshot.empty) {
            res.status(400).json({
                error: 'Database already contains users. Setup can only be run once.'
            });
            return;
        }

        // Sample users data
        const sampleUsers = [
            {
                phone: '+919876543210',
                data: {
                    uid: 'admin',
                    fullName: 'Root Administrator',
                    memberId: 'ADMIN001',
                    referralCode: 'ADMIN',
                    referralLink: 'https://bss-ind-app.web.app/register?ref=ADMIN',
                    referredBy: null,
                    dob: null,
                    email: 'admin@referralpro.com',
                    phone: '+919876543210',
                    pin: '0000',
                    address: {
                        houseNo: null,
                        street: null,
                        villageCity: 'Admin City',
                        mandal: 'Admin Mandal',
                        district: 'Admin District',
                        state: 'Admin State',
                        pincode: null
                    },
                    role: 'Root Administrator',
                    currentRoleLevel: 0,
                    directReferrals: 5,
                    teamReferrals: 25,
                    createdAt: admin.firestore.Timestamp.now()
                }
            },
            {
                phone: '+919876543211',
                data: {
                    uid: 'user1',
                    fullName: 'Rajesh Kumar',
                    memberId: 'REF001',
                    referralCode: 'RAJ2024',
                    referralLink: 'https://bss-ind-app.web.app/register?ref=RAJ2024',
                    referredBy: 'ADMIN',
                    dob: '1990-05-15',
                    email: 'rajesh@example.com',
                    phone: '+919876543211',
                    pin: '1234',
                    address: {
                        houseNo: '123',
                        street: 'MG Road',
                        villageCity: 'Hyderabad',
                        mandal: 'Secunderabad',
                        district: 'Hyderabad',
                        state: 'Telangana',
                        pincode: '500001'
                    },
                    role: 'Volunteer',
                    currentRoleLevel: 2,
                    directReferrals: 12,
                    teamReferrals: 45,
                    createdAt: admin.firestore.Timestamp.now()
                }
            },
            {
                phone: '+919876543212',
                data: {
                    uid: 'user2',
                    fullName: 'Priya Sharma',
                    memberId: 'REF002',
                    referralCode: 'PRI2024',
                    referralLink: 'https://bss-ind-app.web.app/register?ref=PRI2024',
                    referredBy: 'RAJ2024',
                    dob: '1992-08-22',
                    email: 'priya@example.com',
                    phone: '+919876543212',
                    pin: '5678',
                    address: {
                        houseNo: '456',
                        street: 'Jubilee Hills',
                        villageCity: 'Hyderabad',
                        mandal: 'Jubilee Hills',
                        district: 'Hyderabad',
                        state: 'Telangana',
                        pincode: '500033'
                    },
                    role: 'Member',
                    currentRoleLevel: 1,
                    directReferrals: 3,
                    teamReferrals: 8,
                    createdAt: admin.firestore.Timestamp.now()
                }
            },
            {
                phone: '+919876543213',
                data: {
                    uid: 'user3',
                    fullName: 'Amit Patel',
                    memberId: 'REF003',
                    referralCode: 'AMI2024',
                    referralLink: 'https://bss-ind-app.web.app/register?ref=AMI2024',
                    referredBy: 'RAJ2024',
                    dob: '1988-12-10',
                    email: 'amit@example.com',
                    phone: '+919876543213',
                    pin: '9012',
                    address: {
                        houseNo: '789',
                        street: 'Banjara Hills',
                        villageCity: 'Hyderabad',
                        mandal: 'Banjara Hills',
                        district: 'Hyderabad',
                        state: 'Telangana',
                        pincode: '500034'
                    },
                    role: 'Team Leader',
                    currentRoleLevel: 3,
                    directReferrals: 8,
                    teamReferrals: 150,
                    createdAt: admin.firestore.Timestamp.now()
                }
            },
            {
                phone: '+919876543214',
                data: {
                    uid: 'user4',
                    fullName: 'Sunita Reddy',
                    memberId: 'REF004',
                    referralCode: 'SUN2024',
                    referralLink: 'https://bss-ind-app.web.app/register?ref=SUN2024',
                    referredBy: 'PRI2024',
                    dob: '1995-03-18',
                    email: 'sunita@example.com',
                    phone: '+919876543214',
                    pin: '3456',
                    address: {
                        houseNo: '321',
                        street: 'Gachibowli',
                        villageCity: 'Hyderabad',
                        mandal: 'Serilingampally',
                        district: 'Hyderabad',
                        state: 'Telangana',
                        pincode: '500032'
                    },
                    role: 'Member',
                    currentRoleLevel: 1,
                    directReferrals: 2,
                    teamReferrals: 2,
                    createdAt: admin.firestore.Timestamp.now()
                }
            }
        ];

        // Create users in batch
        const batch = db.batch();
        sampleUsers.forEach(user => {
            const userRef = db.collection('users').doc(user.phone);
            batch.set(userRef, user.data);
        });

        await batch.commit();

        logger.log('Database setup completed successfully');

        res.status(200).json({
            success: true,
            message: 'Database setup completed successfully!',
            usersCreated: sampleUsers.length,
            users: sampleUsers.map(u => ({
                name: u.data.fullName,
                phone: u.phone,
                role: u.data.role,
                referralCode: u.data.referralCode
            }))
        });

    } catch (error) {
        logger.error('Error setting up database:', error);
        res.status(500).json({
            error: 'Failed to setup database',
            details: error instanceof Error ? error.message : 'Unknown error'
        });
    }
});
